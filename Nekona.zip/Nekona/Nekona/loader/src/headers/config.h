#pragma once

#define HTTP_SERVER "185.105.4.242"
#define HTTP_PORT 80

#define TFTP_SERVER "185.105.4.242"
